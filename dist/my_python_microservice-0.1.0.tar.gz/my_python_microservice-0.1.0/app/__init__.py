"""
App package initialization.
"""
