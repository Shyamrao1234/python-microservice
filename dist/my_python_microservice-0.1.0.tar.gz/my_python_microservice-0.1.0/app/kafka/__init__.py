"""
Kafka package initialization.
"""
